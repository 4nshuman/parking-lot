import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-slot-initialization',
  templateUrl: './slot-initialization.component.html',
  styleUrls: ['./slot-initialization.component.scss']
})
export class SlotInitializationComponent implements OnInit {
  show: Boolean = false;
  parkings: number;
  carsParked: number;
  constructor(
    private router: Router
  ) { }

  ngOnInit(): void {
  }

  submit(): void{
    this.router.navigateByUrl('/dashboard/'+this.parkings+'/'+this.carsParked);
  }

}
