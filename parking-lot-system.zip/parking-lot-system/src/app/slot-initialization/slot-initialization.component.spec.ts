import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SlotInitializationComponent } from './slot-initialization.component';

describe('SlotInitializationComponent', () => {
  let component: SlotInitializationComponent;
  let fixture: ComponentFixture<SlotInitializationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SlotInitializationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SlotInitializationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
