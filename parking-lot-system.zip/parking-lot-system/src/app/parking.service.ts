import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Car } from './car';
import { CARS } from './mock-cars';

@Injectable({
  providedIn: 'root'
})
export class ParkingService {

  constructor() { }

  getParkingList(numberOfCars: number): Observable<any[]>{
    const list = [];
    let dateTime = new Date();
    for(var i=0; i<numberOfCars; i++){
      list.push({
        car: CARS[i%5],
        slot: i+1,
        date: dateTime
      });
    }
    return of(list);
  }

  addVehicleToParkingList(oldList: any[], newVehicle: Car, totalSlots: number): Observable<any[]>{
    const newList = oldList;
    let dateTime = new Date();
    let slot = -1;
    for(let i=1; i<=totalSlots; i++){
      slot = i;
      newList.forEach(element => {
        if(slot == element.slot){
          slot=-1;
          return;
        }
      });
      if(slot!=-1){
        break;
      }
    }
    newList.push({
      car: newVehicle,
      slot: slot,
      date: dateTime
    });
    return of(newList);
  }

  removeVehicleFromParkingList(oldList: any[], slotForVehicleToBeRemoved: number): Observable<any[]>{
    const newList = [];
    oldList.forEach(element => {
      if(element.slot !== slotForVehicleToBeRemoved){
        newList.push(element);
      }
    });
    return of(newList);
  }

  filterVehiclesByRegistration(vehicleList: any[], regNo: string): Observable<any[]>{
    const results: any[] = []
    vehicleList.forEach(element => {
      if(element.car.regNo.toLowerCase() === regNo.toLowerCase()){
        results.push(element);
      }
    });
    return of(results);
  }

  filterVehiclesByColor(vehicleList: any[], color: string): Observable<any[]>{
    const results: any[] = []
    vehicleList.forEach(element => {
      if(element.car.color.toLowerCase() === color.toLowerCase()){
        results.push(element);
      }
    });
    return of(results);
  }

  filterVehicles(vehicleList: any[], regNo: string, color: string): Observable<any[]>{
    const results: any[] = []
    vehicleList.forEach(element => {
      if(element.car.regNo.toLowerCase() === regNo.toLowerCase()
       && element.car.color.toLowerCase() === color.toLowerCase()){
        results.push(element);
      }
    });
    return of(results);
  }

}
