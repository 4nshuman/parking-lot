import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AmountCollectedModalComponent } from './amount-collected-modal.component';

describe('AmountCollectedModalComponent', () => {
  let component: AmountCollectedModalComponent;
  let fixture: ComponentFixture<AmountCollectedModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmountCollectedModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AmountCollectedModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
