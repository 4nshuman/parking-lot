import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog'

@Component({
  selector: 'app-amount-collected-modal',
  templateUrl: './amount-collected-modal.component.html',
  styleUrls: ['./amount-collected-modal.component.scss']
})
export class AmountCollectedModalComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
  }

}
