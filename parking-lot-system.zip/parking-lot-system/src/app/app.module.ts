import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SlotInitializationComponent } from './slot-initialization/slot-initialization.component';
import { Dash1Component } from './dash1/dash1.component';
import { Dash2Component } from './dash2/dash2.component';
import { AppRoutingModule } from './app-routing.module';
import { ParkNewCarModalComponent } from './park-new-car-modal/park-new-car-modal.component';
import { AmountCollectedModalComponent } from './amount-collected-modal/amount-collected-modal.component';

// Styling modules
import {MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatTableModule} from '@angular/material/table';
import {MatDialogModule} from '@angular/material/dialog';


@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    SlotInitializationComponent,
    Dash1Component,
    Dash2Component,
    ParkNewCarModalComponent,
    AmountCollectedModalComponent
  ],
  entryComponents: [
    ParkNewCarModalComponent,
    AmountCollectedModalComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    AppRoutingModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    MatDialogModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
