import { Component, OnInit, Inject, Output, EventEmitter } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog'
import { Car } from '../car';

@Component({
  selector: 'app-park-new-car-modal',
  templateUrl: './park-new-car-modal.component.html',
  styleUrls: ['./park-new-car-modal.component.scss']
})
export class ParkNewCarModalComponent implements OnInit {
  car: Car = {
    regNo:'',
    color:''
  };
  errorMessage: string;
  successMessage: string;
  @Output() newParkingEvent = new EventEmitter<Car>();
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
  }

  submit(): void{
    if(this.car.regNo!='' && this.car.color!=''){
      this.newParkingEvent.emit(this.car);
      this.errorMessage='';
      this.successMessage='Vehicle successfully parked.';
    }
    else{
      this.successMessage='';
      this.errorMessage='One or more values are missing.'
    }
  }

}
