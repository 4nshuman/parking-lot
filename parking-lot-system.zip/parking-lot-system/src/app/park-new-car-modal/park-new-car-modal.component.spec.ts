import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParkNewCarModalComponent } from './park-new-car-modal.component';

describe('ParkNewCarModalComponent', () => {
  let component: ParkNewCarModalComponent;
  let fixture: ComponentFixture<ParkNewCarModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParkNewCarModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParkNewCarModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
