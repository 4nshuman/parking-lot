import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { ParkNewCarModalComponent } from '../park-new-car-modal/park-new-car-modal.component';
import { AmountCollectedModalComponent } from '../amount-collected-modal/amount-collected-modal.component';
import { Car } from '../car'

@Component({
  selector: 'app-dash1',
  templateUrl: './dash1.component.html',
  styleUrls: ['./dash1.component.scss']
})
export class Dash1Component implements OnInit {
  @Input() parkings:number;
  @Input() parked: number;
  @Input() amount: number;
  @Output() newParkingEvent = new EventEmitter<Car>();

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  parkCar():void{
    let dialogRef = this.dialog.open(
      ParkNewCarModalComponent,
      {data:{parkingAvailable: this.parkings>this.parked}}
    );
    dialogRef.componentInstance.newParkingEvent.subscribe(($newCar) => {
      this.newParkingEvent.emit($newCar);
    })
  }

  showAmountCollection():void{
    let dialogRef = this.dialog.open(
      AmountCollectedModalComponent,
      {data:{amount: this.amount}}
    );
  }

}
