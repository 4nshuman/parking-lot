import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Car } from '../car'
import { ParkingService } from '../parking.service';

@Component({
  selector: 'app-dash2',
  templateUrl: './dash2.component.html',
  styleUrls: ['./dash2.component.scss']
})
export class Dash2Component implements OnInit {
  @Input() vehicleList: any[];
  @Output() newUnparkEvent = new EventEmitter<number>();
  @Output() regNoFilterEvent = new EventEmitter<string>();
  @Output() colorFilterEvent = new EventEmitter<string>();
  @Output() filterEvent = new EventEmitter<any>();
  @Output() filterResetEvent = new EventEmitter();
  regNoSearch: string='';
  colorSearch: string='';

  constructor(private parkingService: ParkingService) { }

  ngOnInit(): void {
  }

  unPark(slotToBeVacated: number): void{
    this.newUnparkEvent.emit(slotToBeVacated);
  }

  execSearch():void{
    if(this.regNoSearch!=='' && this.colorSearch===''){
      this.regNoFilterEvent.emit(this.regNoSearch);
    }
    else if(this.regNoSearch==='' && this.colorSearch!==''){
      this.colorFilterEvent.emit(this.colorSearch);
    }
    else if(this.regNoSearch!=='' && this.colorSearch!==''){
      this.filterEvent.emit({regNo: this.regNoSearch, color: this.colorSearch});
    }
  }

  reset(): void{
    this.regNoSearch='';
    this.colorSearch='';
    this.filterResetEvent.emit();
  }

}
