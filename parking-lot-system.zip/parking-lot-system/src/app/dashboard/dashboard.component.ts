import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Car } from '../car';
import { ParkingService } from '../parking.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: [ './dashboard.component.scss' ]
})
export class DashboardComponent implements OnInit {
  parkings: number;
  parked: number;
  amountCollected: number = 0;
  vehicleList: Car[];
  displayList: Car[];
  dataError: boolean;

  constructor(
    private router: ActivatedRoute,
    private location: Location,
    private parkingService : ParkingService
  ) { }

  ngOnInit() {
    this.setParams();
    if(this.parkings<this.parked){
      this.dataError = true;
    }
    else{
      this.generateParkingList();
    }
  }

  generateParkingList(): void{
    this.parkingService.getParkingList(this.parked)
      .subscribe((list) => {this.vehicleList = list; this.displayList=list});
  }

  setParams(): void{
    this.parkings = +this.router.snapshot.paramMap.get('parkings');
    this.parked = +this.router.snapshot.paramMap.get('parked');
  }

  goBack(): void{
    this.location.back();
  }

  addVehicle(vehicle: Car): void{
    this.parked+=1;
    this.parkingService.addVehicleToParkingList(this.vehicleList, vehicle, this.parkings)
      .subscribe((list) => {this.vehicleList = list; this.displayList=list});
  }

  removeVehicle(slotToBeVacated: number): void{
    this.parkingService.removeVehicleFromParkingList(this.vehicleList, slotToBeVacated)
      .subscribe((list) => {this.vehicleList = list; this.displayList=list});
    this.parked-=1;
    this.amountCollected+=20;
  }

  filterByRegNo(regNo: string){
    this.parkingService.filterVehiclesByRegistration(this.displayList, regNo)
      .subscribe(list => this.displayList=list);
  }

  filterByColor(color: string){
    this.parkingService.filterVehiclesByColor(this.vehicleList, color)
      .subscribe(list => this.displayList=list);
  }

  filter(filterParams: any){
    console.log(filterParams);
    this.parkingService.filterVehicles(this.displayList, filterParams.regNo, filterParams.color)
      .subscribe(list => this.displayList=list);
  }

  reset(){
    this.displayList=[]
    this.vehicleList.forEach(element => {
      this.displayList.push(element);
    });
  }

}
