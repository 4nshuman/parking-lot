export interface Car {
  regNo: string;
  color: string;
}
