import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SlotInitializationComponent } from './slot-initialization/slot-initialization.component'

const routes: Routes = [
  { path: 'dashboard/:parkings/:parked', component: DashboardComponent },
  { path: 'initialize', component: SlotInitializationComponent },
  { path: '', redirectTo: '/initialize', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
