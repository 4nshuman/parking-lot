import { Car } from './car';

export const CARS: Car[] = [
  { regNo: 'KA-64-YX-0619', color: 'Red'},
  { regNo: 'KA-62-AO-1533', color: 'White'},
  { regNo: 'KA-50-MG-5373', color: 'Blue'},
  { regNo: 'KA-58-TW-9181', color: 'Blue'},
  { regNo: 'KA-62-VA-0202', color: 'Black'},
];
